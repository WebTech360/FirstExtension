$(document).ready(function () {
    chrome.tabs.getSelected(null, function (tab) {
        var tablink = tab.url;
        $("#facebook").attr("href", "https://www.facebook.com/sharer/sharer.php?u=" + tablink);
        $("#twitter").attr("href", "http://twitter.com/share?text=it is interesting&url=" + tablink);
        $("#pinterest").attr("href", "http://pinterest.com/pin/create/link/?url=" + tablink);
    });
});